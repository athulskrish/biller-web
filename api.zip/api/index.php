<?php
echo 'You are not allowed to this area';
?>